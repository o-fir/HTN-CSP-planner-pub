## Author
Abdeldjalil Ramoul <abdeldjalil.ramoul@cloud-temple.com>
Damien Pellier <damien.pellier@univ-grenoble-alpes.fr>
Humbert Fiorino <humbert.fiorino@univ-grenoble-alpes.fr>
Sylvie Pesty <sylvie.pesty@univ-grenoble-alpes.fr>

## Paper
Grounding of HTN Planning Domain, Abdeldjalil Ramoul, Damien Pellier, Humbert Fiorino, Sylvie Pesty, IJAIT, 2017
