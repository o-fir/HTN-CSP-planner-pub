#!/bin/bash

## 

python child-snack-generator.py pool 42 30 5 0.6 1.0 > ../problems/p21.hddl
python child-snack-generator.py pool 42 40 6 0.6 1.0 > ../problems/p22.hddl
python child-snack-generator.py pool 42 50 7 0.6 1.0 > ../problems/p23.hddl
python child-snack-generator.py pool 42 70 8 0.6 1.0 > ../problems/p24.hddl
python child-snack-generator.py pool 42 90 9 0.6 1.0 > ../problems/p25.hddl
python child-snack-generator.py pool 42 110 10 0.6 1.0 > ../problems/p26.hddl
python child-snack-generator.py pool 42 150 15 0.6 1.0 > ../problems/p27.hddl
python child-snack-generator.py pool 42 200 20 0.6 1.0 > ../problems/p28.hddl
python child-snack-generator.py pool 42 300 25 0.6 1.0 > ../problems/p29.hddl
python child-snack-generator.py pool 42 500 30 0.6 1.0 > ../problems/p30.hddl
